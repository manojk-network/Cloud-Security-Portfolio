from flask import Flask, request
import boto3
import pymysql
import os

application = Flask(__name__)

S3_BUCKET = os.environ.get('S3_BUCKET')
S3_REGION = 'eu-north-1'

DB_HOST = os.environ.get('DB_HOST')
DB_USER = os.environ.get('DB_USER')
DB_PASSWORD = os.environ.get('DB_PASSWORD')
DB_NAME = os.environ.get('DB_NAME')

s3 = boto3.client('s3', region_name=S3_REGION)

def get_db():
    conn = pymysql.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        cursorclass=pymysql.cursors.DictCursor
    )
    cursor = conn.cursor()
    cursor.execute('CREATE DATABASE IF NOT EXISTS flask_upload')
    cursor.execute('USE flask_upload')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS uploads (
            id INT AUTO_INCREMENT PRIMARY KEY,
            filename VARCHAR(255),
            upload_time DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    return conn

@application.route('/')
def home():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM uploads ORDER BY upload_time DESC')
    files = cursor.fetchall()
    conn.close()

    file_list = ''.join([
        f'<li>{f["filename"]} — {f["upload_time"]}</li>'
        for f in files
    ])

    return f'''
    <h2>Upload a File</h2>
    <form action="/upload" method="post" enctype="multipart/form-data">
        <input type="file" name="file">
        <button type="submit">Upload</button>
    </form>
    <h3>Uploaded Files</h3>
    <ul>{file_list}</ul>
    '''

@application.route('/upload', methods=['POST'])
def upload():
    file = request.files['file']
    s3.upload_fileobj(file, S3_BUCKET, file.filename)

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO uploads (filename) VALUES (%s)', (file.filename,))
    conn.commit()
    conn.close()

    return f"File '{file.filename}' uploaded to S3 and saved to database!"

if __name__ == '__main__':
    application.run(host='0.0.0.0', port=5000)